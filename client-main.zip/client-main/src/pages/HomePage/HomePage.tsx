// экран "Лента", только контентная зона, заглушка с картинкой
import React from 'react';

import styles from './HomePage.module.css';

function HomePage() {
  return (
    <div className={styles.homepage}>
  </div>
  )
}

export default HomePage;
