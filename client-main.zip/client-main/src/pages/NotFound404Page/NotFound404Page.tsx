import React from 'react';

function NotFound404Page() {
  return (
    <div>NotFound404Page</div>
  )
}

export default NotFound404Page;
