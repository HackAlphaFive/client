export const NAME_FOR_404 = '404';

export const PASSWORD = 'superhardpassword1';

export const USER_SUPERIOR = {
  username: 'superior',
  password: PASSWORD,
  id: 1,
}
export const USER_SUBORNIDATE_1 = {
  username: 'subordinate1',
  password: PASSWORD,
  id: 2,
}
export const USER_SUBORNIDATE_5 = {
  username: 'subordinate5',
  password: PASSWORD,
  id: 6,
}
export const USER_SUBORNIDATE_7 = {
  username: 'subordinate7',
  password: PASSWORD,
  id: 8,
}

export const USERS = [USER_SUPERIOR, USER_SUBORNIDATE_1, USER_SUBORNIDATE_5, USER_SUBORNIDATE_7];
